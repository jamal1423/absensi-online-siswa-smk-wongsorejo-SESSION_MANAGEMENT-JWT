<?php

class Session
{
    public function __construct($username,$kelas,$nis)
    {
        $this->username = $username;
        $this->kelas = $kelas;
        $this->nis = $nis;
    }
}

class SessionManager
{

    public static string $SECRET_KEY = "fjnljaicnuwe8nuwvo8nfulvieufksvfukenkfnelvnuf";
    public static function login(string $username, string $password)
    {
        date_default_timezone_set("Asia/Jakarta");
        $issuedAt = time();
        // $expire = $issuedAt + 120; //2 menit
        $expire = $issuedAt + 54000; //1.5 jam
        
        $koneksi = mysqli_connect("localhost","root","","db_absensi");

        $sql = mysqli_query($koneksi,"SELECT * FROM tbl_siswa where username='$username'");
        $row = mysqli_fetch_array($sql);
        $uSiswa = $row['username'];
        $pSiswa = $row['password'];
        $kSiswa = $row['kelas'];
        $nSiswa = $row['nis'];

        if ($username == $uSiswa && md5($password) == $pSiswa) {
            $payload = [
                "username" => $uSiswa,
                "kelas" => $kSiswa,
                "nis" => $nSiswa,
                "iat" => $issuedAt,
                "exp" => $expire
            ];

            $jwt = \Firebase\JWT\JWT::encode($payload, SessionManager::$SECRET_KEY, 'HS256');
            setcookie("X-INOT-SESSION", $jwt);

            return true;
        } else {
            return false;
        }
    }

    public static function getCurrentSession(): Session
    {
        if($_COOKIE['X-INOT-SESSION']){
            $jwt = $_COOKIE['X-INOT-SESSION'];
            try {
                $payload = \Firebase\JWT\JWT::decode($jwt, SessionManager::$SECRET_KEY, ['HS256']);
                return new Session($payload->username,$payload->kelas,$payload->nis);
            }
            catch (Exception $exception){
                throw new Exception("User is not login");
            }
        }else{
            throw new Exception("User is not login");
        }
    }
}
